@echo off
title ProjectApparatus Injector

:: Auto-elevate to admin if not already
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
smi.exe inject -p "Lethal Company" -a ProjectApparatus.dll -n ProjectApparatus -c Loader -m Init
if %errorlevel% neq 0 (
    echo.
    echo Injection failed. Make sure Lethal Company is running.
    pause
)
